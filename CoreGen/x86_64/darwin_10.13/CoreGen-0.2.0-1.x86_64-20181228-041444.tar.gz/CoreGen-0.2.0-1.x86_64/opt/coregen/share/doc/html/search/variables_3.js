var searchData=
[
  ['dag',['DAG',['../class_core_gen_pass.html#a72f6169cbcd6c6a598d5f0d4235d910a',1,'CoreGenPass']]],
  ['destroy',['destroy',['../struct_c_g_plugin_func.html#a436a65257b5dd490163af2942525cd87',1,'CGPluginFunc']]],
  ['doubledata',['DoubleData',['../struct_c_g_feature_val.html#a2c4e73822130c2103121a79fdf39bf63',1,'CGFeatureVal']]]
];
