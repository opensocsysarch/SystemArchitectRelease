var searchData=
[
  ['floatdata',['FloatData',['../struct_c_g_feature_val.html#ad1e03063ebdcfc4ed16327ed485f25e2',1,'CGFeatureVal']]]
];
