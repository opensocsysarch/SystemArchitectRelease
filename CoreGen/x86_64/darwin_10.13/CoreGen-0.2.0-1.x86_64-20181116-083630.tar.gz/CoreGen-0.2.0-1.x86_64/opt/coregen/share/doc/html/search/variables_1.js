var searchData=
[
  ['booldata',['BoolData',['../struct_c_g_feature_val.html#a64becfd9da5445f2ee045285e4da0085',1,'CGFeatureVal']]]
];
