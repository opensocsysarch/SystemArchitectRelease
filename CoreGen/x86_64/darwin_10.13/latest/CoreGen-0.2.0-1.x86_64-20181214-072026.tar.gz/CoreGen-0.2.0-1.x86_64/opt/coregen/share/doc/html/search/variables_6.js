var searchData=
[
  ['getname',['getname',['../struct_c_g_plugin_func.html#ad2f626e24c49c70c4c2243a79ebfb2e6',1,'CGPluginFunc']]]
];
