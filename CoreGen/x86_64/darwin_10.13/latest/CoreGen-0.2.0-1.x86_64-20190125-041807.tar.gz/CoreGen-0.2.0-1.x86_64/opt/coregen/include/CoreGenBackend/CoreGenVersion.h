//
// _CoreGenVersion_h_
//
// Copyright (C) 2017-2018 Tactical Computing Laboratories, LLC
// All Rights Reserved
// contact@tactcomplabs.com
//
// See LICENSE in the top level directory for licensing details
//

#ifndef _COREGENVERSION_H_
#define _COREGENVERSION_H_

#define CoreGenBackend_VERSION_MAJOR 0
#define CoreGenBackend_VERSION_MINOR 2

#endif

/* EOF */
