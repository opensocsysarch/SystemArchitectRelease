var searchData=
[
  ['stringdata',['StringData',['../struct_c_g_feature_val.html#a724e98f265430c56405e6390bcc06be4',1,'CGFeatureVal']]]
];
