var searchData=
[
  ['int32tdata',['Int32tData',['../struct_c_g_feature_val.html#ab84ffc18ac0bac27cb350c2f27a2dfd4',1,'CGFeatureVal']]],
  ['int64tdata',['Int64tData',['../struct_c_g_feature_val.html#afa64f3c21452f64a8b4332d6b4d3c8f6',1,'CGFeatureVal']]]
];
