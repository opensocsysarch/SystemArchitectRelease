var searchData=
[
  ['coregen_20high_20level_20soc_20design_20framework',['CoreGen High Level SoC Design Framework',['../group___core_gen.html',1,'']]]
];
