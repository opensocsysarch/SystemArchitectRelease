var searchData=
[
  ['create',['create',['../struct_c_g_plugin_func.html#a78941c06966e53bfecf740b548aa0e9a',1,'CGPluginFunc']]]
];
